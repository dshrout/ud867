package com.dshrout.fungi;

public class JokeSmith {
    public JokeVM getJoke(){
        return new JokeVM("What do you call a smart blond?", "A Golden Retriever!");
    }
}
